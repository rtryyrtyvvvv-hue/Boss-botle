const players = [
  ["Sən","🧑"],["Aysel","👩"],["Murad","👨"],["Nigar","👩‍🦰"],
  ["Elvin","👨‍🦱"],["Leyla","👩‍🦳"],["Kamran","🧔"],["Zəhra","👩‍🦱"],
  ["Orxan","👨‍🦰"],["Sevinc","👩"],["Tural","👨"],["Günel","👩‍🦰"]
];

const box=document.getElementById("players");
const center=[50,50], rx=42, ry=43;
players.forEach((p,i)=>{
  const a=(i/players.length)*Math.PI*2-Math.PI/2;
  const x=center[0]+Math.cos(a)*rx;
  const y=center[1]+Math.sin(a)*ry;
  const el=document.createElement("div");
  el.className="player";
  el.style.left=`calc(${x}% - 38px)`;
  el.style.top=`calc(${y}% - 35px)`;
  el.innerHTML=`<div class="avatar">${p[1]}</div><div class="pname">${p[0]}</div>`;
  box.appendChild(el);
});

let coins=100, spinning=false, dailyClaimed=false;
const coinsEl=document.getElementById("coins");
const bottle=document.getElementById("bottle");
const status=document.getElementById("status");

document.getElementById("spinBtn").onclick=()=>{
  if(spinning) return;
  if(coins<5){status.textContent="🪙 Fırlatmaq üçün 5 coin lazımdır.";return;}
  coins-=5; coinsEl.textContent=coins; spinning=true;
  status.textContent="Şüşə fırlanır...";
  bottle.classList.remove("spin"); void bottle.offsetWidth; bottle.classList.add("spin");
  setTimeout(()=>{
    const target=players[Math.floor(Math.random()*players.length)][0];
    status.textContent=`🎯 Şüşə ${target} oyunçusunu seçdi!`;
    spinning=false;
  },2800);
};

document.getElementById("bonusBtn").onclick=()=>{
  if(dailyClaimed){status.textContent="🎁 Bugünkü bonus artıq götürülüb.";return;}
  dailyClaimed=true; coins+=25; coinsEl.textContent=coins;
  status.textContent="🎁 +25 pulsuz bonus əlavə olundu!";
};

document.getElementById("giveBtn").onclick=()=>{
  const amount=Math.max(1,Number(document.getElementById("bonusAmount").value)||0);
  coins+=amount; coinsEl.textContent=coins;
  status.textContent=`👑 Admin bonusu: +${amount} coin`;
};
